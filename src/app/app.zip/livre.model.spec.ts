import { Livre } from './livre.model';

describe('Livre', () => {
  it('should create an instance', () => {
    expect(new Livre()).toBeTruthy();
  });
});
